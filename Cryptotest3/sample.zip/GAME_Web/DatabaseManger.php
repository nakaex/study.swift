<?php

define("DB_HOST","localhost");
define("DB_USER","root");
define("DB_PASS","root");
define("DB_NAME","gametest");

class DatabaseManager {
	private $host = DB_HOST;
	private $user = DB_USER;
	private $pass = DB_PASS;
	private $name = DB_NAME;

	public function __construct() {
	}
	public function connect() {
		// MySQL サーバーへの接続をオープンする		
		if (!($pdo = new PDO("mysql:host={$this->host};dbname={$this->name};charset=utf8;",
				$this->user,$this->pass,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET CHARACTER SET `utf8`")))) {
			throw new Exception('接続できませんでした'.mysql_error());
		}
		return $pdo;
	}
	public function insertParentID($pdo, $parent_id) {
		$sql = 'INSERT INTO parent_ids (parent_id) VALUES (:parent_id)';

		$st = $pdo->prepare($sql);
        $st->bindParam(':parent_id', $parent_id, PDO::PARAM_STR);
		$st->execute();
	}
	public function insertChildID($pdo, $parent_id) {
		$pdo->beginTransaction();

		$sql = 'INSERT INTO child_ids (parent_id,child_id) VALUES (?,?)';
		$st = $pdo->prepare($sql);

		for ($n = 1; $n <= 10000; $n++) {
			$child_id = sprintf("%06d", $n);
			$st->execute(array($parent_id,$child_id));
		}

		$pdo->commit();
	}

	public function chackUserNo($pdo, $user_no) {
                unset($data);
                $sql="SELECT COUNT(*) AS count FROM goover3.users WHERE user_no = :user_no";
                $st = $pdo->prepare($sql);
                $st->bindParam(':user_no', $user_no);
                $st->execute();

                if(!($data = $st->fetchAll(PDO::FETCH_ASSOC))) {
                        $data = array();
                }
                return (int)$data[0]['count'];
        }

}
?>
