<?php

$array = array(
        "name" => "あらゆ",
        "gender" => "男",
        "blog" => array(
                "name" => "Syncer",
                "published" => "2014-06-10",
                "url" => "http://syncer.jp/",
        ),
);
$json = json_encode($array);


//暗号化方式をRIJNDAELの256bitブロック長、暗号化方式をCBC
$iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_CBC);  

//Initial Vectorの大きさ
echo "iv size:" . $iv_size . "\n";

//Initial Vector生成
$iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
echo "iv value:" . base64_encode( $iv ) . "\n";

//共通鍵
$key = "secret key!!!!!!";



//暗号化したい平文
$text = $json;
echo "PlainText Value:" . $text . "\n";

//暗号化方式をRIJNDAELの256bitブロック長、暗号化方式をCBC
$crypttext = mcrypt_encrypt(MCRYPT_RIJNDAEL_256, $key, $text, MCRYPT_MODE_CBC, $iv);
echo "Crypt Value:" . base64_encode( $crypttext ) . "\n";

//復号化
$decrypttext = mcrypt_decrypt(MCRYPT_RIJNDAEL_256, $key, $crypttext, MCRYPT_MODE_CBC, $iv);
echo "DeCrypt Value:" . $decrypttext . "\n";

$tmp = json_decode( $decrypttext , true );

var_dump($tmp);