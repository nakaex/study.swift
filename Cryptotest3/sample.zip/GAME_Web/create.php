<?php
require_once 'DatabaseManger.php';

try {
	# データベース接続
	$db = new DatabaseManager();
	$pdo = $db->connect();
	
	for ($n = 1; $n <= 4; $n++) {
		$parent_id = sprintf("%03d",$n);
		$db->insertParentID($pdo, $parent_id);
		$db->insertChildID($pdo, $parent_id);
	}

	$pdo = null;
} catch (Exception $e) {
echo "例外:".$e->getMessage();
	error_log("例外:".$e->getMessage(), 0);
	$pdo = NULL;
}

?>
