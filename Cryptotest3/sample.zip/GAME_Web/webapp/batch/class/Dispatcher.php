<?php

namespace QR;

class Dispatcher {
    private $sysRoot;
    private $batchRoot;
    private $argv;
    private $argc;
    private $argument;

    function __construct($argv, $argc) {
        $this->argv = $argv;
        $this->argc = $argc;
        $this->argument = $argv;
        @array_shift($this->argument);
    }

    public function setSystemRoot($path) {
        $this->sysRoot = rtrim($path, '/');
    }
    public function setBatchRoot($path) {
        $this->batchRoot = rtrim($path, '/');
    }

    public function dispatch() {
        // １番目のパラメーターをコントローラーとして取得
        $webapp = "index";
        if (1 < $this->argc) {
            $webapp = $this->argv[1];
            @array_shift($this->argument);
        }
        // パラメータより取得したコントローラー名によりクラス振分け
        $className = ucfirst(strtolower($webapp)) . 'Batch';

        // 2番目のパラメーターをコントローラーとして取得
        $action = 'index';
        if (2 < $this->argc) {
            $action = $this->argv[2];
            @array_shift($this->argument);
        }
        // 引数チェック
        if (!count($this->argument)) {
            $this->argument = NULL;
        }
        // 設定ファイル読込
        require_once $this->sysRoot . '/config/config.php';
        // ログクラスファイル読込
        require_once $this->sysRoot . '/class/Logger.php';
        // データベースクラスファイル読込
        require_once $this->sysRoot . '/class/Database.php';
        // Baseクラスファイル読込
        require_once $this->batchRoot . '/batch.php';
        // クラスファイル読込
        require_once $this->batchRoot . '/app/' . $className . '.php';

        // 定数定義
        global $CONFIG;
        $CONFIG['Log.path'] = $this->batchRoot . '/tmp/logs/';
        $CONFIG['Lock.path'] = $this->sysRoot . '/data/lock/';
        $CONFIG['Lock.file'] = $this->sysRoot . '/data/lock/' . $className . '.' . $action . '.lock';
        $CONFIG['Log.class'] = $className;
        $CONFIG['Log.action'] = $action;

        // クラスインスタンス生成
        $webappInstance = new $className($this->argument);

        // アクションメソッドを実行
        $actionMethod = $action;
        $webappInstance->$actionMethod();
    }
}