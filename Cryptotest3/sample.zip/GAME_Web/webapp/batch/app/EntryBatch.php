<?php
class EntryBatch extends Batch {
    private $sqlQuery = array(
        'GET.Parent' => 'SELECT M_GAME_ID.id, M_GAME_ID.parent_id FROM m_game_ids M_GAME_ID WHERE M_GAME_ID.active = 1 ORDER BY RAND() LIMIT 1',
        'GET.Child'  => 'SELECT GAME_ID.id, GAME_ID.parent_id, GAME_ID.child_id  FROM game_ids GAME_ID WHERE GAME_ID.parent_id = ? ORDER BY RAND() LIMIT 1',
        'ADD.User'   => 'INSERT INTO users (game_id, secrecy_code) VALUES (?,?)',
        'ADD.Entry'  => 'INSERT INTO entries (user_id, game_id, secrecy_code) SELECT id, game_id, secrecy_code FROM users WHERE id = ?',
        'DEL.Child'  => 'DELETE FROM game_ids WHERE id = ?',
        'UPD.Parent' => 'UPDATE m_game_ids M_GAME_ID SET M_GAME_ID.active = 0 WHERE 0 = (SELECT COUNT(*) cnt FROM game_ids GAME_ID WHERE GAME_ID.parent_id = ?)',
    );
    public function test() {
        echo "test\n";
    }
    public function index() {
        global $CONFIG;
        try {
            // デバイスチェック
            if (!$this->deviceCheck()) {
                throw new Exception('Device Error', $CONFIG['E_CODE']['Device']);
            }
            // パラメータチェック
            if (!$this->_parameterCheck()) {
                throw new Exception('Parameter Error', $CONFIG['E_CODE']['Parameter']);
            }
            // DB接続
            if (!$this->databaseConnect()) {
                throw new Exception('Cannot connect database', $CONFIG['E_CODE']['Database']);
            }
            $result = array('result' => $CONFIG['Result']['OK']);
        }
        catch (Exception $e) {
            // 例外処理
            $result = array('result' => $CONFIG['Result']['Error'], 'message' => $e->getMessage(), 'e_code' => $e->getCode());
            \QR\Logger::log($this->error_log($e));
        }
        // 結果を返す
        echo json_encode($result);
    }
    private function _parameterCheck() {
        return true;
    }
    private function _entry() {
        global $CONFIG;

        //
        $sql = $this->sqlQuery['GET.Parent'];
        $res = $this->db->execFetchAll($sql);
        if (!count($res)) {
            throw new Exception($sql, $CONFIG['E_CODE']['SQL.Select']);
        }
        $this->data['parent'] = $res[0];

        //
        $sql = $this->sqlQuery['GET.Child'];
        $param = array($this->data['parent']['parent_id']);
        $res = $this->db->execFetchAll($sql, $param);
        if (!count($res)) {
            throw new Exception($sql, $CONFIG['E_CODE']['SQL.Select']);
        }
        $this->data['child'] = $res[0];

        //
        $this->db->beginTransaction();

        //
        $sql = $this->sqlQuery['ADD.User'];
        $secrecy_code = substr(str_shuffle('123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, 9);
        $param = array(
            $this->data['child']['parent_id'].$this->data['child']['child_id'],
            $secrecy_code);
        if (!$this->db->save($sql, $param)) {
            $this->db->rollBack();
            throw new Exception($sql, $CONFIG['E_CODE']['SQL.Insert']);
        }
        $this->data['user']['id'] = $this->db->lastInsertId();

        //
        $sql = $this->sqlQuery['ADD.Entry'];
        if (!$this->db->save($sql, array($this->data['user']['id']))) {
            $this->db->rollBack();
            throw new Exception($sql, $CONFIG['E_CODE']['SQL.Insert']);
        }

        //
        $sql = $this->sqlQuery['DEL.Child'];
        if (!$this->db->save($sql, array($this->data['child']['id']))) {
            $this->db->rollBack();
            throw new Exception($sql, $CONFIG['E_CODE']['SQL.Delete']);
        }

        //
        $sql = $this->sqlQuery['UPD.Parent'];
        if (!$this->db->save($sql, array($this->data['parent']['parent_id']))) {
            $this->db->rollBack();
            throw new Exception($sql, $CONFIG['E_CODE']['SQL.Update']);
        }

        //
        $this->db->commit();
    }
}