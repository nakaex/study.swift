<?php
class RegistryBatch extends Batch {
    private $sqlQuery = array(
            'GET.CheckPID' => 'SELECT COUNT(*) cnt FROM m_game_ids WHERE parent_id = ?',
            'ADD.PID'      => 'INSERT INTO m_game_ids (parent_id) VALUES (?)',
            'GET.PID'      => 'SELECT M_GAME_ID.parent_id, M_GAME_ID.start, (M_GAME_ID.end + M_GAME_ID.increase) end FROM m_game_ids M_GAME_ID WHERE M_GAME_ID.active = 1 AND M_GAME_ID.parent_id = ?',
            'ADD.GID'      => 'INSERT INTO game_ids (game_id, parent_id, child_id) VALUES (?,?,?)',
            'UPD.PID'      => 'UPDATE m_game_ids SET start = start + increase, end = end + increase WHERE parent_id = ?',
    );
    private $setID;
    public function active_on() {
        global $CONFIG;
        
        try {
            // デバイスチェック
            if (!$this->deviceCheck()) {
                throw new Exception('Device Error', $CONFIG['E_CODE']['Device']);
            }
            // パラメータチェック
            if (!$this->_parameterCheck()) {
                throw new Exception('Parameter Error', $CONFIG['E_CODE']['Parameter']);
            }
            // DB接続
            if (!$this->databaseConnect()) {
                throw new Exception('Cannot connect database', $CONFIG['E_CODE']['Database']);
            }
            // 処理結果 成功の場合
            $result = array('result' => $CONFIG['Result']['OK']);
        }
        catch (Exception $e) {
            // 例外処理
            $result = array('result' => $CONFIG['Result']['Error'], 'message' => $e->getMessage(), 'code' => $e->getCode());
            \QR\Logger::log($this->error_log($e));
        }
        // 結果を返す
        echo json_encode($result);
    }
    public function active_off() {
        global $CONFIG;
        
        try {
            // デバイスチェック
            if (!$this->deviceCheck()) {
                throw new Exception('Device Error', $CONFIG['E_CODE']['Device']);
            }
            // パラメータチェック
            if (!$this->_parameterCheck()) {
                throw new Exception('Parameter Error', $CONFIG['E_CODE']['Parameter']);
            }
            // DB接続
            if (!$this->databaseConnect()) {
                throw new Exception('Cannot connect database', $CONFIG['E_CODE']['Database']);
            }
            // 処理結果 成功の場合
            $result = array('result' => $CONFIG['Result']['OK']);
        }
        catch (Exception $e) {
            // 例外処理
            $result = array('result' => $CONFIG['Result']['Error'], 'message' => $e->getMessage(), 'code' => $e->getCode());
            \QR\Logger::log($this->error_log($e));
        }
        // 結果を返す
        echo json_encode($result);
    }
    public function create_masterid() {
        global $CONFIG;

        try {
            // デバイスチェック
            if (!$this->deviceCheck()) {
                throw new Exception('Device Error', $CONFIG['E_CODE']['Device']);
            }
            // パラメータチェック
            if (!$this->_parameterCheck()) {
                throw new Exception('Parameter Error', $CONFIG['E_CODE']['Parameter']);
            }
            // DB接続
            if (!$this->databaseConnect()) {
                throw new Exception('Cannot connect database', $CONFIG['E_CODE']['Database']);
            }
            $this->_create_masterid();
            // 処理結果 成功の場合
            $result = array('result' => $CONFIG['Result']['OK']);
        }
        catch (Exception $e) {
            // 例外処理
            $result = array('result' => $CONFIG['Result']['Error'], 'message' => $e->getMessage(), 'code' => $e->getCode());
            \QR\Logger::log($this->error_log($e));
        }
        // 結果を返す
        echo json_encode($result);
    }
    public function create_gameid() {
        global $CONFIG;

        try {
            // デバイスチェック
            if (!$this->deviceCheck()) {
                throw new Exception('Device Error', $CONFIG['E_CODE']['Device']);
            }
            // パラメータチェック
            if (!$this->_parameterCheck()) {
                throw new Exception('Parameter Error', $CONFIG['E_CODE']['Parameter']);
            }
            // DB接続
            if (!$this->databaseConnect()) {
                throw new Exception('Cannot connect database', $CONFIG['E_CODE']['Database']);
            }
            $this->_create_gameid();
            // 処理結果 成功の場合
            $result = array('result' => $CONFIG['Result']['OK']);
        }
        catch (Exception $e) {
            // 例外処理
            $result = array('result' => $CONFIG['Result']['Error'], 'message' => $e->getMessage(), 'code' => $e->getCode());
            \QR\Logger::log($this->error_log($e));
        }
        // 結果を返す
        echo json_encode($result);
    }
    private function _parameterCheck() {
        if (!isset($this->params[0])) {
            return false;
        }
        $this->setID = $this->params[0];
        return true;
    }
    private function _create_masterid() {
        $parent_id = $this->setID;

        $sql = $this->sqlQuery['GET.CheckPID'];
        $res = $this->db->execFetchAll($sql, array($parent_id));
        if (intval($res[0]['cnt'])) {
            throw new Exception($sql, $CONFIG['E_CODE']['SQL.Select']);
        }

        //
        $this->db->beginTransaction();

        $sql = $this->sqlQuery['ADD.PID'];
        if (!$this->db->save($sql, array($parent_id))) {
            $this->db->rollBack();
            throw new Exception($sql, $CONFIG['E_CODE']['SQL.Insert']);
        }

        //
        $this->db->commit();

        return true;
    }
    private function _create_gameid() {
        $sql = $this->sqlQuery['GET.PID'];
        $res = $this->db->execFetchAll($sql, array($this->setID));
        if (!count($res)) {
            throw new Exception($sql, $CONFIG['E_CODE']['SQL.Select']);
        }
        $this->data['parent'] = $res[0];

        //
        $this->db->beginTransaction();

        //
        $sql = $this->sqlQuery['ADD.GID'];
        $parent_id = $this->data['parent']['parent_id'];
        for ($n = $this->data['parent']['start']; $n <= $this->data['parent']['end']; $n++) {
            $child_id = sprintf("%06d", $n);
            $param[] = array($parent_id.$child_id, $parent_id, $child_id);
        }
        if (!$this->db->save($sql, $param)) {
            $this->db->rollBack();
            throw new Exception($sql, $CONFIG['E_CODE']['SQL.Insert']);
        }

        //
        $sql = $this->sqlQuery['UPD.PID'];
        if (!$this->db->save($sql, array($parent_id))) {
            $this->db->rollBack();
            throw new Exception($sql, $CONFIG['E_CODE']['SQL.Update']);
        }

        //
        $this->db->commit();
    
        return true;
    }
}