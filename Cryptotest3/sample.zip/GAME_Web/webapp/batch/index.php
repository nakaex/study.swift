<?php
// バッチディレクトリパス
define('BATCH_PATH', dirname(__FILE__));
// システムディレクトリパス
define('SYSTEM_PATH', realpath(dirname(__FILE__) . '/..'));

require_once (BATCH_PATH . '/class/Dispatcher.php');

$dispatcher = new \QR\Dispatcher($argv, $argc);
$dispatcher->setBatchRoot(BATCH_PATH);
$dispatcher->setSystemRoot(SYSTEM_PATH);
$dispatcher->dispatch();