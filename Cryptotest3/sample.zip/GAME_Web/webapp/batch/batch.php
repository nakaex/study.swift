<?php
class Batch {
    protected $data;
    protected $params;
    protected $db;

    function __construct($argument = NULL) {
        $this->db = new Database();
        $this->params = $argument;
    }
    function __destruct() {
        unset($this->data);
        unset($this->params);
        unset($this->db);
    }
    protected function databaseConnect() {
        return $this->db->connect();
    }
    protected function deviceCheck() {
        return true;
    }
    protected function error_log(Exception $e) {
        return sprintf("File[%s] Line[%s] [%s] E_CODE[%s]",$e->getFile(), $e->getLine(), $e->getMessage(), $e->getCode());
    }
    protected function log_data($data) {
        foreach ($data as $k => $v) {
            \QR\Logger::log($k . ' ' . $v);
        }
    }
}