
/**/
CREATE TABLE m_game_ids (
    id          BIGINT  AUTO_INCREMENT PRIMARY KEY COMMENT '連番',
    parent_id   CHAR(3) UNIQUE         NOT NULL    COMMENT '発行 親ID番号',
    active      BOOLEAN DEFAULT 0      NOT NULL    COMMENT '発行許可フラグ',
    start       INT     DEFAULT 1      NOT NULL    COMMENT 'ID発行 先頭番号', 
    end         INT     DEFAULT 0      NOT NULL    COMMENT 'ID発行 終了番号', 
    increase    INT     DEFAULT 10000  NOT NULL    COMMENT 'ID発行 値'
);
ALTER TABLE m_game_ids COMMENT 'ゲームID 発行マスタ';

/**/
CREATE TABLE game_ids (
    id        BIGINT  AUTO_INCREMENT PRIMARY KEY COMMENT '連番',
    game_id   CHAR(9) UNIQUE         NOT NULL    COMMENT 'ゲームID',
    parent_id CHAR(3) NOT NULL                   COMMENT '親ID',
    child_id  CHAR(6) NOT NULL                   COMMENT '子ID',
    INDEX idx_parent_id(parent_id)
);
ALTER TABLE game_ids COMMENT 'ゲームID 発行テーブル';

/**/
CREATE TABLE entries (
	id           BIGINT  AUTO_INCREMENT PRIMARY KEY COMMENT '連番',
	user_id      BIGINT  UNIQUE         NOT NULL    COMMENT 'ユーザーID',
    game_id      CHAR(9) UNIQUE         NOT NULL    COMMENT 'ゲームID',
    secrecy_code CHAR(9) NOT NULL                   COMMENT '秘密コード'
);
ALTER TABLE entries COMMENT '登録管理 テーブル';

/**/
CREATE TABLE users (
    id           BIGINT      AUTO_INCREMENT PRIMARY KEY COMMENT 'ユーザーID',
    game_id      CHAR(9)     UNIQUE         NOT NULL    COMMENT 'ゲームID',
    secrecy_code CHAR(9)     NOT NULL                   COMMENT '秘密コード',
    nickname     VARCHAR(30) DEFAULT ''                 COMMENT 'ニックネーム',
    gold         INT         DEFAULT 0 NOT NULL         COMMENT 'ゴールド',
    del_flg      BOOLEAN     DEFAULT 0 NOT NULL         COMMENT '論理 削除フラグ'
);
ALTER TABLE users COMMENT 'ユーザー テーブル';



