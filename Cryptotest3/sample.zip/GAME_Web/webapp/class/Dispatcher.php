<?php
class Dispatcher {
    private $sysRoot;

    public function setSystemRoot($path) {
        $this->sysRoot = rtrim($path, '/');
    }

    public function dispatch() {
        // パラメーター取得（末尾の / は削除）
        $param = ereg_replace('/?$', '', ereg_replace(SYSTEM_PATH . '/', '', $_SERVER['REQUEST_URI']));

        $params = array();
        if ('' != $param) {
            // パラメーターを / で分割
            $params = explode('/', $param);
        }

        // １番目のパラメーターをコントローラーとして取得
        $webapp = "index";
        if (0 < count($params)) {
            $webapp = $params[0];
        }
        $module = $webapp;
        $client = gethostname();

        // パラメータより取得したコントローラー名によりクラス振分け
        $className = ucfirst(strtolower($webapp)) . 'Webapp';

        // 設定ファイル読込
        require_once $this->sysRoot . '/config/config.php';
        // ログクラスファイル読込
        require_once $this->sysRoot . '/class/Logger.php';
        // データベースクラスファイル読込
        require_once $this->sysRoot . '/class/Database.php';
        // Baseクラスファイル読込
        require_once $this->sysRoot . '/webapp.php';
        // クラスファイル読込
        require_once $this->sysRoot . '/app/' . $className . '.php';

        // 定数定義
        Config::write('Conn.module', $webapp);
        Config::write('Conn.client', gethostname());
        Config::write('Log.path', $this->sysRoot . '/tmp/logs/');

        Logger::log('[START]=====================================================================================================================');

        // クラスインスタンス生成
        $webappInstance = new $className();

        // 2番目のパラメーターをコントローラーとして取得
        $action = 'index';
        if (1 < count($params)) {
            $action = $params[1];
        }

        // アクションメソッドを実行
        $actionMethod = $action;
        $webappInstance->$actionMethod();

        Logger::log('[END]=======================================================================================================================');
    }
}