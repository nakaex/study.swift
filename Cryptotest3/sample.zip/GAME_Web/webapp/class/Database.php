<?php
//namespace QR;

class Database {
    private $connect;
    private $pdo;

    public function __construct() {
        $this->connect = Config::param('Database.Connect');
    }
    function __destruct() {
        $this->pdo = NULL;
    }
    public function connect() {
        // MySQL サーバーへの接続をオープンする
        if (!($this->pdo = new PDO("mysql:host={$this->connect['host']};dbname={$this->connect['name']};charset=utf8;",
            $this->connect['user'],$this->connect['pass'],array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET CHARACTER SET `utf8`")))) {
            return false;
        }
        return true;
    }
    /*
     * 成功した場合に TRUE を、失敗した場合に FALSE を返します。
     */
    public function beginTransaction() {
        return $this->pdo->beginTransaction();
    }
    /*
     * 成功した場合に TRUE を、失敗した場合に FALSE を返します。
     */
    public function rollBack() {
        return $this->pdo->rollBack();
    }
    /*
     * 成功した場合に TRUE を、失敗した場合に FALSE を返します。
     */
    public function commit() {
        return $this->pdo->commit();
    }
    public function execFetchAll($sql, $parameters = NULL) {
        $sth = $this->pdo->prepare($sql);
        $exec = (!isset($parameters)) ? $sth->execute() : $sth->execute($parameters);
        return $exec ? $sth->fetchAll(PDO::FETCH_ASSOC) : $exec;
    }
    public function save($sql, $parameters) {
        $sth = $this->pdo->prepare($sql);

        if (is_array($parameters) && is_array($parameters[0])) {
            foreach ($parameters as $param) {
                if (!$sth->execute($param)) {
                    return false;
                }
            }
            return true;
        }
        else {
            return $sth->execute($parameters);
        }
    }
    public function lastInsertId() {
        return $this->pdo->lastInsertId();
    }
}