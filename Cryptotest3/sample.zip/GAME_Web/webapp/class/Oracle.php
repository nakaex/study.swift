<?php
class Db {
    private $conn = null;
    private $stid = null;
    private $prefetch = 100;
    private $action;
    private $connect;

    function __construct() {
        $this->connect = Config::param('Database.Connect');
    }
    function __destruct() {
        if ($this->stid) {
            oci_free_statement($this->stid);
        }
        if ($this->conn) {
            oci_close($this->conn);
        }
    }
    public function connect($module, $cid) {
        $this->conn = @oci_pconnect($this->connect['schema'], $this->connect['password'], $this->connect['database'], $this->connect['charset']);
        if (!$this->conn) {
            $e = oci_error($this->conn);
            Logger::log('oci_error : [message:'.$e['message'].']');
            return false;
        }
        oci_set_client_info($this->conn, CLIENT_INFO);
        oci_set_module_name($this->conn, $module);
        oci_set_client_identifier($this->conn, $cid);
        $this->action = $module;
        return true;
    }
    public function execute($sql, $action, $bindvars = array()) {
        $this->stid = oci_parse($this->conn, $sql);
        if ($this->prefetch >=0) {
            oci_set_prefetch($this->stid, $this->prefetch);
        }
        foreach ($bindvars as $bv) {
            oci_bind_by_name($this->stid, $bv[0], $bv[1], $bv[2]);
        }
        oci_set_action($this->conn, $action);
        $ret = oci_execute($this->stid, OCI_NO_AUTO_COMMIT);
        if (!$ret) {
            $e = oci_error($this->stid);
            Logger::log('oci_error : [message:'.$e['message'].'] [sqltext:'.$e['sqltext'].']');
            return false;
        }
        return true;
    }
    public function execFetchAll($sql, $bindvars = array(), $action = NULL) {
        $action = is_null($action) ? $this->action : $action;
        $this->execute($sql, $action, $bindvars);
        oci_fetch_all($this->stid, $res, 0, -1, OCI_FETCHSTATEMENT_BY_ROW);
        $this->stid = null;
        return($res);
    }

    public function commit() {
        $ret = oci_commit($this->conn);
        if (!$ret) {
            $e = oci_error($this->conn);
            Logger::log('oci_error : [message:'.$e['message'].']');
            return false;
        }
        return true;
    }
}