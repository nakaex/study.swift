<?php
class Logger {
    private static $instance = null;

    private function __construct() {
    }

    public static function getInstance() {
        if (!self::$instance) self::$instance = new self;
        return self::$instance;
    }

    public function log($message, $mode = 'debug', $file = 'app', $message_type = 3, $destination = NULL) {
        $file_date = date('Ymd');

        switch ($mode) {
            case 'debug':
                $log_file = 'debug_' . $file_date . '.log';
                break;
        }

        $message = date('[Y-m-d H:i:s]: ') . $_SERVER['REQUEST_URI'] . ' ' . $message;
        $message .= "\n";
        error_log($message, $message_type, Config::param('Log.path') . $log_file);
    }
}