<?php
require_once 'lib/Config/ENV.php';

// 環境変数クラス
class Config extends Config_ENV {
    const RESPONSE_RESULT_STATUS = "resultStatus";
    const RESPONSE_MESSAGE = "message";
    const RESPONSE_CODE = "code";
    const SQL_ERROR_MESSAGE = "SQL Error";
    const CANNOT_CONNECT_DATABASE_MESSAGE = "Cannot connect database";
    const PARAMETER_ERROR_MESSAGE = "Parameter Error";
    const DEVICE_ERROR_MESSAGE = "Device Error";
}

// << .htaccessのSetEnvで設定変更する場合は、SetEnv APP_ENV の値を変更する >>
// << 環境変数を直接設定する場合 コメントを消去する >>
//$_SERVER['APP_ENV'] = 'development';

// 環境変数 APP_ENV の値に従い設定を切替える
Config::envname('APP_ENV');

// APP_ENV が未定義の場合は 'development' モード
Config::defaultenv('development');

// 環境変数の値に依存しない共通の設定値
Config::common(array(
    'E_CODE' => array(
        'Device'     => 101, // デバイスエラー
        'Parameter'  => 201, // パラメータエラー
        'Database'   => 301, // データベース接続エラー
        'SQL.Select' => 401, // SLQ SELECT エラー
        'SQL.Insert' => 401, // SLQ INSERT エラー
        'SQL.Update' => 402, // SLQ UPDATE エラー
        'SQL.Delete' => 403, // SLQ DELETE エラー
        'Upload'     => 501, // Upload エラー
        'Validation' => 601, // Validation エラー
        'System'     => 999, // その他のシステム エラー
    ),
    'R_CODE' => array(
        'OK'    => 1, // 正常終了
        'NG'    => 0, // エラー
    ),
));

## 環境変数 APP_ENV (.htaccessのSetEnv値) の値に応じた設定を記述 ##
// ローカル環境用
Config::config('local', array(
    'Database.Connect' => array(
        'host' => 'localhost',
        'user' => 'root',
        'pass' => 'root',
        'name' => 'gametest',
    ),
    'Openssl' => array(
        'key' => '1234567890asdfgh',
        'method' => 'AES-128-ECB',
    ),
    'Key.Private' => '1234567890asdfgh',
));
// 開発環境用
Config::config('development', array(
    'Database.Connect' => array(
        'schema'      => '',
        'password'    => '',
        'charset'     => 'JA16SJIS',
        'client_info' => '',
        'database'    => '',
    ),
));
// 本番環境用
Config::config('production', array(
    'Database.Connect' => array(
        'schema'      => 'usr01',
        'password'    => '12345',
        'charset'     => 'JA16SJIS',
        'client_info' => '',
        'database'    => 'localhost.localdomain/XE',
    ),
));
