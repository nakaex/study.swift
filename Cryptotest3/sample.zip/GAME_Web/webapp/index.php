<?php
// ルートディレクトリパス
define('ROOT_PATH', realpath(dirname(__FILE__) . '/..'));
// システムディレクトリパス
define('SYSTEM_PATH', ereg_replace(ROOT_PATH, '', realpath(dirname(__FILE__))));

require_once (ROOT_PATH . SYSTEM_PATH . '/class/Dispatcher.php');

$dispatcher = new Dispatcher();
$dispatcher->setSystemRoot(ROOT_PATH . SYSTEM_PATH);
$dispatcher->dispatch();