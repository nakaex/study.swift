<?php
class LoginWebapp extends Webapp {
    private $json;
    const REQUEST_LOGIN = 'loginRequest';
    const RESPONSE_LOGIN = 'loginResponse';

    public function index() {
        try {
            // デバイスチェック
            if (!$this->deviceCheck()) {
                throw new Exception(Config::DEVICE_ERROR_MESSAGE, $this->E_CODE['Device']);
            }
            // パラメータチェック
            if (!$this->_parameterCheck()) {
                throw new Exception(Config::PARAMETER_ERROR_MESSAGE, $this->E_CODE['Parameter']);
            }
            // DB接続
            if (!$this->databaseConnect()) {
                throw new Exception(Config::CANNOT_CONNECT_DATABASE_MESSAGE, $this->E_CODE['Database']);
            }
            // 入力チェック
            $validat = $this->_validation();
            if ($validat) {
                throw new Exception($validat['msg'], $this->E_CODE['Validation']);
            }
            // ログインチェック
            $client = $this->_checkLogin();
            if (!count($client)) {
                throw new Exception('ID・パスワードが正しくありません。', $this->R_CODE['NG']);
            }
/*
            // 認証チェック
            $attestation = $this->_checkAttestation();
            if (!count($attestation)) {
                throw new Exception('契約が有効ではありません。', $this->R_CODE['NG']);
            }
*/
            // ユーザー 一覧取得
            $users = $this->_getUsers();
            if (!count($users)) {
                $users = null;
            }
            // 結果をセット
            $result = array(LoginWebapp::RESPONSE_LOGIN => array(
                Config::RESPONSE_RESULT_STATUS => $this->R_CODE['OK'],
                Config::RESPONSE_DATE => array(Config::RESPONSE_USER_LIST => $users)
            ));
        }
        catch (Exception $e) {
            // 例外処理
            $result = array(LoginWebapp::RESPONSE_LOGIN => array(
                Config::RESPONSE_RESULT_STATUS => $this->R_CODE['NG'],
                 Config::RESPONSE_MESSAGE => $e->getMessage(),
                 Config::RESPONSE_CODE => $e->getCode()));
            Logger::log($this->error_log($e));
        }
        // 結果を返す
        $this->log_var_dump($result);
        echo json_encode($result);
    }
    private function _parameterCheck() {
        $this->log_var_dump($this->params);
        if (isset($this->params[LoginWebapp::REQUEST_LOGIN])) {
            $this->json = json_decode($this->params[LoginWebapp::REQUEST_LOGIN], true);
            return true;
        }
        else {
            return false;
        }
    }
    private function _validation() {
        return false;
    }
    private function _checkLogin() {
        $sql = 'select * from QRUSERS QRUSER where QRUSER.QRUSER_ID = :QRUSER_ID AND QRUSER.PASSWORD = :PASSWORD';
        $param = array(
            array(':QRUSER_ID', $this->params['userId'], -1),
            array(':PASSWORD', $this->params['password'], -1)
        );

        $res = $this->db->execFetchAll($sql, $param);

        return count($res);
    }
}
