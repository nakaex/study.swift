<?php
class EncryptWebapp extends Webapp {
    public function test_AA() {
        $array = array(
                "name" => "naka",
        );
        $json = json_encode($array);
        $data = $json;
        $password = 'Soul Gem';
        // Set a random salt
        $salt = openssl_random_pseudo_bytes(16);
        
        $salted = '';
        $dx = '';
        // Salt the key(32) and iv(16) = 48
        while (strlen($salted) < 48) {
            $dx = hash('sha256', $dx.$password.$salt, true);
            $salted .= $dx;
        }
        
        $key = substr($salted, 0, 32);
        $iv  = substr($salted, 32,16);
        
        $encrypted_data = openssl_encrypt($data, 'AES-256-CBC', $key, true, $iv);
        
        $encry = base64_encode($salt . $encrypted_data);
        Logger::log2($encry,"debug");
        echo $encry;
        
        /*
        
        return base64_encode($salt . $encrypted_data);
        */
    }
    public function test5() {
        $file = '/var/www/html/webapp/data/tmp.txt';
        $homepage = file_get_contents($file);
        echo $homepage;
    }
    public function test4() {
        $key = '1234567890asdfgh';
        $bite16 = $this->params['data'];
        Logger::log2('data='. $bite16,"debug");
        $return = pack("H*" ,$bite16);
        $encode = base64_encode($return);
        $p_t = openssl_decrypt($encode, 'AES-128-ECB', $key);
//        $p_t = mb_convert_encoding($p_t, "SJIS");
//        $p_t = mb_convert_encoding($p_t, "SJIS-win", "UTF-8");
        Logger::log2('plain_text='. $p_t,"debug");
        $file = '/var/www/html/webapp/data/tmp.txt';
        file_put_contents($file, $p_t);
    }
    public function test3() {
        $this->log_params();
        Logger::log2('request='. $_POST['request'],"debug");
        $array = array(
                "kakeru" => "12345",
                "CCCCC" => "abcdfe",
                "SDADWD" => "JSKANDNSADKJS",
                "DUHAIDUIHIUHUD" => "SDASKLKM",
                "adjanjknkjan" => "dadlms",
                "namea" => "mesafaewf",
                "nameb" => "adkfnkef121223fuierfiundjfbeaifbeqiufhudncoeqnfiuernuvireqnvinjedcenfvuiherqiuhgruieghuireh48321758913658913659813269852379hf931hd18893hfd98134",
                "namec" => "121223",
                "namer" => "hfd98134",
                "nameVb" => "adkfnkef121223fuierfiundjfbeaifbeqiufhudncoeqnfiuernuvireqnvinjedcenfvuiherqiuhgruieghuireh48321758913658913659813269852379hf931hd18893hfd98134",
                "nameVVb" => "ad",
                "nameVbc" => "adkfnkef121223fuierfiundjfbeaifbeqiufhudncoeqnfiuernuvireqnvinjedcenfvuiherqiuhgruieghuireh48321758913658913659813269852379hf931hd18893hfd98134",
                "nameVbcc" => "adkfnkef121223fuierfiundjfbeaifbeqiufhudncoeqnfiuernuvireqnvinjedcenfvuiherqiuhgruieghuireh48321758913658913659813269852379hf931hd18893hfd98134",
                "nameVbcb" => "adkfnkef121223fuierfiundjfbeaifbeqiufhudncoeqnfiuernuvireqnvinjedcenfvuiherqiuhgruieghuireh48321758913658913659813269852379hf931hd18893hfd98134",
                "nameVbc1" => "adkfnkef121223fuierfiundjfbeaifbeqiufhudncoeqnfiuernuvireqnvinjedcenfvuiherqiuhgruieghuireh48321758913658913659813269852379hf931hd18893hfd98134",
        
                "ZnameVbc" => "adkfnkef121223fuierfiundjfbeaifbeqiufhudncoeqnfiuernuvireqnvinjedcenfvuiherqiuhgruieghuireh48321758913658913659813269852379hf931hd18893hfd98134",
                "XnameVbcc" => "arfiundjfbeaifbeqiufhudncoeqnfiuernuvireqnvinjedcenfvuiherqiuhgruieghuireh48321758913658913659813269852379hf931hd18893hfd98134",
                "VnameVbcb" => "adkfnkef121223fuierfiundjfbeaifbeqiufhudncoeqnfiuernuvireqnvinjedcenfvuiherqiuhgruieghuireh48321758913658913659813269852379hf931hd18893hfd98134",
                "BnameVbc1" => "Test女まどか☆ギカ魔法少女まどか☆マギカ魔法少女まどか☆マギカ魔法少女まどqjsh２３魔法少女cadsまどdecodeか☆マギwqfuihhwudduywgdカ魔法dwくぅえひうぇhふぃおえhうぃおf少女まどか☆マギカ魔法少まどをいくぇじょいじぇふぃ１３１２３４１２か☆マギカ魔法少女まど法少女まどか☆マbwhb女まど243erか☆マギカ魔法少女まどか☆マギカ魔法少女まどか☆マギカ魔法少女まどか☆マギカ魔法少女まどか☆マギカ魔法少女まどか☆マギカ魔法少女まどqjuy4eedr22４３４１3r1gdcadscuygaushか☆女まどか☆マギカ魔法少女まどか☆マギカ魔法少女まどか☆マギカ魔法少女まどか☆マギカ魔法少女まどか☆マギカ魔法少女ccまど３１４か234☆マギ42カ32魔法少女まどqjshマギカ魔法少女まどか☆マギカdwopdkweqopdk魔法少女まどか☆マギカ魔法少女まどか☆マギカ魔法少女まどf12133324３２４かq☆マギカ魔法少女まどか☆23434124マギカ魔法少女まどか☆マギ女まどか☆マギカ魔法少女まどか☆マギカ魔法少女まどか☆マギカ魔法少女まどか☆マfギカ魔法少女まどか☆マギカ魔法少女まどか☆マギカ魔法少女まどqjshカカE n d",
        
        );
        $json = json_encode($array);
        
        $key = '1234567890asdfgh';
        $plain_text = $json;#"Test女まどか☆ギカ魔法少女まどか☆マギカ魔法少女まどか☆マギカ魔法少女まどqjsh２３魔法少女cadsまどdecodeか☆マギwqfuihhwudduywgdカ魔法dwくぅえひうぇhふぃおえhうぃおf少女まどか☆マギカ魔法少まどをいくぇじょいじぇふぃ１３１２３４１２か☆マギカ魔法少女まど法少女まどか☆マbwhb女まど243erか☆マギカ魔法少女まどか☆マギカ魔法少女まどか☆マギカ魔法少女まどか☆マギカ魔法少女まどか☆マギカ魔法少女まどか☆マギカ魔法少女まどqjuy4eedr22４３４１3r1gdcadscuygaushか☆女まどか☆マギカ魔法少女まどか☆マギカ魔法少女まどか☆マギカ魔法少女まどか☆マギカ魔法少女まどか☆マギカ魔法少女ccまど３１４か234☆マギ42カ32魔法少女まどqjshマギカ魔法少女まどか☆マギカdwopdkweqopdk魔法少女まどか☆マギカ魔法少女まどか☆マギカ魔法少女まどf12133324３２４かq☆マギカ魔法少女まどか☆23434124マギカ魔法少女まどか☆マギ女まどか☆マギカ魔法少女まどか☆マギカ魔法少女まどか☆マギカ魔法少女まどか☆マfギカ魔法少女まどか☆マギカ魔法少女まどか☆マギカ魔法少女まどqjshカカE n d";
        Logger::log2($method .' plain_text='. $plain_text,"debug");
        //openssl
        $c_t = openssl_encrypt($plain_text, 'AES-128-ECB', $key, true);
        $bite16 = bin2hex($c_t);

        echo $bite16;
    }
    
    public function test2() {
        $key = '1234567890asdfgh';
        $plain_text = "ABCabc";

        //openssl
        $c_t = openssl_encrypt($plain_text, 'AES-128-ECB', $key, true);
        $bite16 = bin2hex($c_t);
        $return = pack("H*" ,$bite16);
        $encode = base64_encode($return);
        var_dump ($bite16);
        var_dump ($return);
        var_dump ($encode);
        $p_t = openssl_decrypt($encode, 'AES-128-ECB', $key);
        var_dump($plain_text, $c_t, $p_t);
    }
    function dec_to_hex($dec)
    {
        $sign = ""; // suppress errors
        if( $dec < 0){ $sign = "-"; $dec = abs($dec); }
    
        $hex = Array( 0 => 0, 1 => 1, 2 => 2, 3 => 3, 4 => 4, 5 => 5,
                6 => 6, 7 => 7, 8 => 8, 9 => 9, 10 => 'a',
                11 => 'b', 12 => 'c', 13 => 'd', 14 => 'e',
                15 => 'f' );
    
        do
        {
            $h = $hex[($dec%16)] . $h;
            $dec /= 16;
        }
        while( $dec >= 1 );
    
        return $sign . $h;
    }
    public function test() {
        $array = array(
                "kakeru" => "12345",
                "CCCCC" => "abcdfe",
                "SDADWD" => "JSKANDNSADKJS",
                "DUHAIDUIHIUHUD" => "SDASKLKM",
                "adjanjknkjan" => "dadlms",
                "namea" => "mesafaewf",
                "nameb" => "adkfnkef121223fuierfiundjfbeaifbeqiufhudncoeqnfiuernuvireqnvinjedcenfvuiherqiuhgruieghuireh48321758913658913659813269852379hf931hd18893hfd98134",
                "namec" => "121223",
                "namer" => "hfd98134",
                "nameVb" => "adkfnkef121223fuierfiundjfbeaifbeqiufhudncoeqnfiuernuvireqnvinjedcenfvuiherqiuhgruieghuireh48321758913658913659813269852379hf931hd18893hfd98134",
                "nameVVb" => "ad",
                "nameVbc" => "adkfnkef121223fuierfiundjfbeaifbeqiufhudncoeqnfiuernuvireqnvinjedcenfvuiherqiuhgruieghuireh48321758913658913659813269852379hf931hd18893hfd98134",
                "nameVbcc" => "adkfnkef121223fuierfiundjfbeaifbeqiufhudncoeqnfiuernuvireqnvinjedcenfvuiherqiuhgruieghuireh48321758913658913659813269852379hf931hd18893hfd98134",
                "nameVbcb" => "adkfnkef121223fuierfiundjfbeaifbeqiufhudncoeqnfiuernuvireqnvinjedcenfvuiherqiuhgruieghuireh48321758913658913659813269852379hf931hd18893hfd98134",
                "nameVbc1" => "adkfnkef121223fuierfiundjfbeaifbeqiufhudncoeqnfiuernuvireqnvinjedcenfvuiherqiuhgruieghuireh48321758913658913659813269852379hf931hd18893hfd98134",
                
                "ZnameVbc" => "adkfnkef121223fuierfiundjfbeaifbeqiufhudncoeqnfiuernuvireqnvinjedcenfvuiherqiuhgruieghuireh48321758913658913659813269852379hf931hd18893hfd98134",
                "XnameVbcc" => "arfiundjfbeaifbeqiufhudncoeqnfiuernuvireqnvinjedcenfvuiherqiuhgruieghuireh48321758913658913659813269852379hf931hd18893hfd98134",
                "VnameVbcb" => "adkfnkef121223fuierfiundjfbeaifbeqiufhudncoeqnfiuernuvireqnvinjedcenfvuiherqiuhgruieghuireh48321758913658913659813269852379hf931hd18893hfd98134",
                "BnameVbc1" => "hfd98134",
                
        );
        $json = json_encode($array);
        $message = "aaaaaaaaカ魔法少女まどか☆マギカ魔法aaaaaカ魔法少女まどか☆マギカ魔aaaaカ魔法少女まどか☆マギカ魔aaaaカ魔法少女まどか☆マギカ魔aaaaカ魔法少女まどか☆マギカ魔aaaaカ魔法少女まどか☆マギカ魔aaaaカ魔法少女まどか☆マギカ魔aaaaカ魔法少女まどか☆マギカ魔aaaaカ魔法少女まどか☆マギカ魔aaaaカ魔法少女まどか☆マギカ魔aaaaカ魔法少女まどか☆マギカ魔aaaaカ魔法少女まどか☆マギカ魔aaaaカ魔法少女まどか☆マギカ魔aaaaカ魔法少女まどか☆マギカ魔aaaaカ魔法少女まどか☆マギカ魔aaaaカ魔法少女まどか☆マギカ魔aaaaカ魔";
        Logger::log2('message= '. $message,"debug");
        $key = '1234567890asdfgh';
        $method = 'aes-128-ecb'; //
        $crypto = openssl_encrypt($message, $method, $key);
        Logger::log2($method .'base64_encode='. base64_encode($crypto),"debug");
        Logger::log2($method .'='. ($crypto),"debug");
//        $msg = openssl_decrypt( $crypto, $method, $key );
//        Logger::log2($method .'=' . $msg,"debug");
        echo base64_encode($crypto);
    }
    public function index() {
        $array = array(
                "name" => "あらゆ",
                "gender" => "男",
                "blog" => array(
                        "name" => "Syncer",
                        "published" => "2014-06-10",
                        "url" => "http://syncer.jp/",
                ),
        );
        $json = json_encode($array);

        //暗号化方式をRIJNDAELの256bitブロック長、暗号化方式をCBC
        $iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_CBC);

        //Initial Vectorの大きさ
//        echo "iv size:" . $iv_size . "\n";
        
        //Initial Vector生成
        $iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
//        echo "iv value:" . base64_encode( $iv ) . "\n";

        //共通鍵
        $key = "secret key!!!!!!";

        //暗号化したい平文
        $text = $json;
//        echo "PlainText Value:" . $text . "\n";

        //暗号化方式をRIJNDAELの256bitブロック長、暗号化方式をCBC
        $crypttext = mcrypt_encrypt(MCRYPT_RIJNDAEL_256, $key, $text, MCRYPT_MODE_CBC, $iv);
        $encrypt = base64_encode($crypttext);
        echo $encrypt;
        Logger::log2($encrypt,"debug");
/*
        //復号化
        $decrypttext = mcrypt_decrypt(MCRYPT_RIJNDAEL_256, $key, $crypttext, MCRYPT_MODE_CBC, $iv);
        echo "DeCrypt Value:" . $decrypttext . "\n";
        
        $tmp = json_decode( $decrypttext , true );
        
        var_dump($tmp);
*/
    }
    private function _parameterCheck() {
        return true;
    }
    private function _entry() {
        global $CONFIG;

        //
        $sql = $this->sqlQuery['GET.Parent'];
        $res = $this->db->execFetchAll($sql);
        if (!count($res)) {
            throw new Exception($sql, $CONFIG['E_CODE']['SQL.Select']);
        }
        $this->data['parent'] = $res[0];

        //
        $sql = $this->sqlQuery['GET.Child'];
        $param = array($this->data['parent']['parent_id']);
        $res = $this->db->execFetchAll($sql, $param);
        if (!count($res)) {
            throw new Exception($sql, $CONFIG['E_CODE']['SQL.Select']);
        }
        $this->data['child'] = $res[0];

        //
        $this->db->beginTransaction();

        //
        $sql = $this->sqlQuery['ADD.User'];
        $secrecy_code = substr(str_shuffle('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, 9);
        $param = array(
                $this->data['child']['parent_id'].$this->data['child']['child_id'],
                $secrecy_code);
        if (!$this->db->save($sql, $param)) {
            $this->db->rollBack();
            throw new Exception($sql, $CONFIG['E_CODE']['SQL.Insert']);
        }
        $this->data['user']['id'] = $this->db->lastInsertId();

        //
        $sql = $this->sqlQuery['ADD.Entry'];
        if (!$this->db->save($sql, array($this->data['user']['id']))) {
            $this->db->rollBack();
            throw new Exception($sql, $CONFIG['E_CODE']['SQL.Insert']);
        }

        //
        $sql = $this->sqlQuery['DEL.Child'];
        if (!$this->db->save($sql, array($this->data['child']['id']))) {
            $this->db->rollBack();
            throw new Exception($sql, $CONFIG['E_CODE']['SQL.Delete']);
        }

        //
        $sql = $this->sqlQuery['UPD.Parent'];
        if (!$this->db->save($sql, array($this->data['parent']['parent_id']))) {
            $this->db->rollBack();
            throw new Exception($sql, $CONFIG['E_CODE']['SQL.Update']);
        }

        //
        $this->db->commit();
    }
}