<?php
class RegisterWebapp extends Webapp {
    private $json;
    const REQUEST_REGISTER = 'registerRequest';
    const RESPONSE_REGISTER = 'registerResponse';

    public function index() {
        try {
            // デバイスチェック
            if (!$this->deviceCheck()) {
                throw new Exception(Config::DEVICE_ERROR_MESSAGE, $this->E_CODE['Device']);
            }
            // パラメータチェック
            if (!$this->_parameterCheck()) {
                throw new Exception(Config::PARAMETER_ERROR_MESSAGE, $this->E_CODE['Parameter']);
            }
            // DB接続
            if (!$this->databaseConnect()) {
                throw new Exception(Config::CANNOT_CONNECT_DATABASE_MESSAGE, $this->E_CODE['Database']);
            }
            // 入力チェック
            $validat = $this->_validation();
            if ($validat) {
                throw new Exception($validat['msg'], $this->E_CODE['Validation']);
            }
            // 保存
            if (!$this->_save()) {
                throw new Exception(Config::SQL_ERROR_MESSAGE, $this->E_CODE['SQL.Insert']);
            }
            // 処理結果 成功の場合
            $result = array(RegisterWebapp::RESPONSE_REGISTER => array(
                Config::RESPONSE_RESULT_STATUS => $this->R_CODE['OK']));
        }
        catch (Exception $e) {
            // 例外処理
            $result = array(RegisterWebapp::RESPONSE_REGISTER => array(
                Config::RESPONSE_RESULT_STATUS => $this->R_CODE['NG'], 
                Config::RESPONSE_MESSAGE => $e->getMessage(), 
                Config::RESPONSE_CODE => $e->getCode()));
            Logger::log($this->error_log($e));
        }
        // 結果を返す
        $this->log_var_dump($result);
        echo json_encode($result);
    }
    private function _parameterCheck() {
        $this->log_var_dump($this->params);
        if (isset($this->params[RegisterWebapp::REQUEST_REGISTER])) {
            $this->json = json_decode($this->params[RegisterWebapp::REQUEST_REGISTER], true);
            return true;
        }
        else {
            return false;
        }
    }
    private function _validation() {
        return false;
    }
    private function _save() {
        $sql = $this->_getRegisterSqlQuery();

        foreach ($this->json['Data'] as $k => $v) {
            $tmp = $this->_getRegisterParams($v);
            mb_convert_variables('SJIS','UTF-8',$tmp); // INSERT用に文字コードを変換する
            if (!$this->db->execute($sql, Config::param('Conn.module'), $tmp)) {
                return false;
            }
        }
        $this->db->commit();
        return true;
    }
    private function _getRegisterParams($param) {
        return array(
            array(':USER_ID', $param['USER_ID'], -1),
            array(':CLIENT_ID', $param['CLIENT_ID'], -1),
            array(':CAR_TYPE', $param['CAR_TYPE'], -1),
            array(':VERSION1', $param['VERSION1'], -1),
            array(':CAR_NUM', $param['CAR_NUM'], -1),
            array(':PLACE_NM', $param['PLACE_NM'], -1),
            array(':CLASS_NUM', $param['CLASS_NUM'], -1),
            array(':PLACE_KANA', $param['PLACE_KANA'], -1),
            array(':FLEET_NUM', $param['FLEET_NUM'], -1),
            array(':PLATE_NUM', $param['PLATE_NUM'], -1),
            array(':CHASSIS_NUM', $param['CHASSIS_NUM'], -1),
            array(':MOTOR_MODEL', $param['MOTOR_MODEL'], -1),
            array(':FORM_TYPE', $param['FORM_TYPE'], -1),
            array(':VERSION2', $param['VERSION2'], -1),
            array(':EMBOSSING_POSITION', $param['EMBOSSING_POSITION'], -1),
            array(':MODEL_CLASS_NUM', $param['MODEL_CLASS_NUM'], -1),
            array(':EXPIRATION_DATE', $param['EXPIRATION_DATE'], -1),
            array(':REGISTRATION_DATE', $param['REGISTRATION_DATE'], -1),
            array(':MODEL', $param['MODEL'], -1),
            array(':AXLE_LOAD_11', $param['AXLE_LOAD_11'], -1),
            array(':AXLE_LOAD_10', $param['AXLE_LOAD_10'], -1),
            array(':AXLE_LOAD_01', $param['AXLE_LOAD_01'], -1),
            array(':AXLE_LOAD_00', $param['AXLE_LOAD_00'], -1),
            array(':NOISE', $param['NOISE'], -1),
            array(':EXHAUST_SOUND_VALUE', $param['EXHAUST_SOUND_VALUE'], -1),
            array(':DRIVE_SYSTEM', $param['DRIVE_SYSTEM'], -1),
            array(':OPASHIMETA', $param['OPASHIMETA'], -1),
            array(':NOX_PM', $param['NOX_PM'], -1),
            array(':NOX_VALUE', $param['NOX_VALUE'], -1),
            array(':PM_VALUE', $param['PM_VALUE'], -1),
            array(':SAFETY_DATE', $param['SAFETY_DATE'], -1),
            array(':FUEL_CODE', $param['FUEL_CODE'], -1),
            array(':SYSTEM_ID1', $param['SYSTEM_ID1'], -1),
            array(':SYSTEM_ID2', $param['SYSTEM_ID2'], -1),
            array(':PRELIMINARY_ITEM', $param['PRELIMINARY_ITEM'], -1),
        );
    }
    private function _getRegisterSqlQuery() {
        $sql = 'INSERT INTO SG_QRCODE_CARS (';
        $sql .= 'CAR_ID';
        $sql .= ',USER_ID';
        $sql .= ',CLIENT_ID';
        $sql .= ',CAR_TYPE';
        $sql .= ',VERSION1';
        $sql .= ',CAR_NUM';
        $sql .= ',PLACE_NM';
        $sql .= ',CLASS_NUM';
        $sql .= ',PLACE_KANA';
        $sql .= ',FLEET_NUM';
        $sql .= ',PLATE_NUM';
        $sql .= ',CHASSIS_NUM';
        $sql .= ',MOTOR_MODEL';
        $sql .= ',FORM_TYPE';
        $sql .= ',VERSION2';
        $sql .= ',EMBOSSING_POSITION';
        $sql .= ',MODEL_CLASS_NUM';
        $sql .= ',EXPIRATION_DATE';
        $sql .= ',REGISTRATION_DATE';
        $sql .= ',MODEL';
        $sql .= ',AXLE_LOAD_11';
        $sql .= ',AXLE_LOAD_10';
        $sql .= ',AXLE_LOAD_01';
        $sql .= ',AXLE_LOAD_00';
        $sql .= ',NOISE';
        $sql .= ',EXHAUST_SOUND_VALUE';
        $sql .= ',DRIVE_SYSTEM';
        $sql .= ',OPASHIMETA';
        $sql .= ',NOX_PM';
        $sql .= ',NOX_VALUE';
        $sql .= ',PM_VALUE';
        $sql .= ',SAFETY_DATE';
        $sql .= ',FUEL_CODE';
        $sql .= ',SYSTEM_ID1';
        $sql .= ',SYSTEM_ID2';
        $sql .= ',PRELIMINARY_ITEM';
        $sql .= ',INS_DATE';
        $sql .= ') VALUES (';
        $sql .= 'SG_QRCODE_CARS_SEQ.NEXTVAL';
        $sql .= ',:USER_ID';
        $sql .= ',:CLIENT_ID';
        $sql .= ',:CAR_TYPE';
        $sql .= ',:VERSION1';
        $sql .= ',:CAR_NUM';
        $sql .= ',:PLACE_NM';
        $sql .= ',:CLASS_NUM';
        $sql .= ',:PLACE_KANA';
        $sql .= ',:FLEET_NUM';
        $sql .= ',:PLATE_NUM';
        $sql .= ',:CHASSIS_NUM';
        $sql .= ',:MOTOR_MODEL';
        $sql .= ',:FORM_TYPE';
        $sql .= ',:VERSION2';
        $sql .= ',:EMBOSSING_POSITION';
        $sql .= ',:MODEL_CLASS_NUM';
        $sql .= ",TO_TIMESTAMP(:EXPIRATION_DATE, 'YYYY-MM-DD HH24:MI:SS')";
        $sql .= ",TO_TIMESTAMP(:REGISTRATION_DATE, 'YYYY-MM-DD HH24:MI:SS')";
        $sql .= ',:MODEL';
        $sql .= ',:AXLE_LOAD_11';
        $sql .= ',:AXLE_LOAD_10';
        $sql .= ',:AXLE_LOAD_01';
        $sql .= ',:AXLE_LOAD_00';
        $sql .= ',:NOISE';
        $sql .= ',:EXHAUST_SOUND_VALUE';
        $sql .= ',:DRIVE_SYSTEM';
        $sql .= ',:OPASHIMETA';
        $sql .= ',:NOX_PM';
        $sql .= ',:NOX_VALUE';
        $sql .= ',:PM_VALUE';
        $sql .= ",TO_TIMESTAMP(:SAFETY_DATE, 'YYYY-MM-DD HH24:MI:SS')";
        $sql .= ',:FUEL_CODE';
        $sql .= ',:SYSTEM_ID1';
        $sql .= ',:SYSTEM_ID2';
        $sql .= ',:PRELIMINARY_ITEM';
        $sql .= ',sysdate';
        $sql .= ')';

        return $sql;
    }
    private function _upload() {
        $path = Config::param('Image.path') . '00001' . '/';
        @mkdir($path);
        foreach ($_FILES as $key => $item) {
            if ($_FILES[$key]['error'] === UPLOAD_ERR_OK) {
                $filename = $path . $_FILES[$key]['name'];
                // アップロードファイルされたテンポラリファイルをファイル格納パスにコピーする
                $result = @move_uploaded_file($_FILES[$key]['tmp_name'], $filename);
                @chmod($filename, 0644);
            }
        }
        return true;
    }
}