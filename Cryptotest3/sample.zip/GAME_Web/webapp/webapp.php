<?php
class Webapp {
    protected $params;
    protected $db;
    protected $E_CODE;
    protected $R_CODE;
    protected $headers;

    function __construct() {
        $this->db = new Database();
        $this->params = $_REQUEST;
        $this->headers = getallheaders();
        $this->E_CODE = Config::param('E_CODE');
        $this->R_CODE = Config::param('R_CODE');
    }
    function __destruct() {
        unset($this->params);
        unset($this->db);
    }
    protected function databaseConnect() {
        return $this->db->connect();
    }
    protected function deviceCheck() {
        $user_agent = $_SERVER["HTTP_USER_AGENT"];
        Logger::log("HTTP_USER_AGENT:".$user_agent);
        return ((stripos($user_agent,'iphone') !== false) || (stripos($user_agent,'ipad') !== false) || (stripos($user_agent,'android') !== false));
    }
    protected function error_log(Exception $e) {
        return sprintf("File[%s] Line[%s] [%s] E_CODE[%s]",$e->getFile(), $e->getLine(), $e->getMessage(), $e->getCode());
    }
    protected function log_serverinfo() {
        foreach($_SERVER as $server_key => $server_val) {
            Logger::log($server_key . ' => ' . $server_val);
        }
    }
    protected function log_var_dump($v = array()) {
        ob_start();
        var_dump($v);
        $log = ob_get_contents();
        ob_end_clean();
        Logger::log($log);
    }
    protected function log_params() {
        foreach ($this->params as $k => $v) {
            Logger::log($k . ' ' . $v);
        }
    }
}